<?php
global $em_smokes;
$em_smokes = array();
$em_smokes['1'] = '不吸烟';
$em_smokes['2'] = '偶尔吸一点';
$em_smokes['3'] = '抽得很凶';
?>