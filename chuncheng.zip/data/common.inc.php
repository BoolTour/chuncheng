<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'chengchun';//chengchun
$cfg_dbuser = 'chuncheng';//root
$cfg_dbpwd = 'linuxcxs123';//root
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>